const express = require('express'); const router = express.Router(); const Appointment = require('../models/Appointment');
router.get('/', async (req,res)=>{ const appts = await Appointment.findAll({limit:5}); res.json(appts);});
module.exports = router;
const express = require('express'); const router = express.Router(); const Patient = require('../models/Patient');
router.get('/', async (req,res)=>{ const pts = await Patient.findAll({limit:5}); res.json(pts);});
router.post('/', async (req,res)=>{ try{ const p = await Patient.create(req.body); res.status(201).json(p);}catch(e){res.status(400).json({error:e.message});}});
module.exports = router;
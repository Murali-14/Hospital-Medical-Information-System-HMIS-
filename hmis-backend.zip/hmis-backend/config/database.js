const { Sequelize } = require('sequelize');
const sequelize = new Sequelize(process.env.PG_DB || 'hmisdb', process.env.PG_USER || 'postgres',
  process.env.PG_PASS || 'postgres', { host: process.env.PG_HOST || 'localhost', dialect: 'postgres', logging: false });
module.exports = sequelize;
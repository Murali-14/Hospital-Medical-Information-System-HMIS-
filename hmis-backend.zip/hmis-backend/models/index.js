const sequelize = require('../config/database');
const Department = require('./Department'); const Staff = require('./Staff'); const Patient = require('./Patient'); const Appointment = require('./Appointment');
const Bill = require('./Bill'); const Diagnostic = require('./Diagnostic'); const Medicine = require('./Medicine'); const Prescription = require('./Prescription');
const PrescriptionItem = require('./PrescriptionItem'); const ICUBed = require('./ICUBed'); const User = require('./User');
// (Associations omitted for brevity in zip) 
module.exports = {sequelize,Department,Staff,Patient,Appointment,Bill,Diagnostic,Medicine,Prescription,PrescriptionItem,ICUBed,User};